# amazon-linux-ami: Latest Public AMIs

**WARNING! Do NOT use these AMIs in a production setting.** They are meant only to make
    initial experiments with this module more convenient.

| AWS Region | AMI ID |
| ---------- | ------ |
| ap-south-1 | ami-0ea8063bcb5c3c091 |
| eu-west-3 | ami-0deb97140d616c41d |
| eu-west-2 | ami-09190cac25852ec51 |
| eu-west-1 | ami-02af80eeea70904d6 |
| ap-northeast-2 | ami-05a5488797b7ef368 |
| ap-northeast-1 | ami-0c0ba7872ccd06eb4 |
| sa-east-1 | ami-0a2179a1066ae7977 |
| ca-central-1 | ami-04b1276d4d89075bd |
| ap-southeast-1 | ami-054e9b4818c755a1c |
| ap-southeast-2 | ami-010418febb1da7aef |
| eu-central-1 | ami-0f9e3b0b35660456e |
| us-east-1 | ami-0d717cc4e86c58260 |
| us-east-2 | ami-00747decb3a911d40 |
| us-west-1 | ami-073bf913f38f59bdb |
| us-west-2 | ami-0c757e8c7577457db |
