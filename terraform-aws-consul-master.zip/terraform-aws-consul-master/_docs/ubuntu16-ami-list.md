# ubuntu16-ami: Latest Public AMIs

**WARNING! Do NOT use these AMIs in a production setting.** They are meant only to make
    initial experiments with this module more convenient.

| AWS Region | AMI ID |
| ---------- | ------ |
| eu-north-1 | ami-00505daaea792d417 |
| ap-south-1 | ami-066d5b23cdee62544 |
| eu-west-3 | ami-05077a6e96b330d43 |
| eu-west-2 | ami-078bee56f2baba890 |
| eu-west-1 | ami-02d704b4b23793050 |
| ap-northeast-2 | ami-02c4fecc046509587 |
| ap-northeast-1 | ami-0ed5c5475b16b9ef7 |
| sa-east-1 | ami-0c2e446acc79fc7bc |
| ca-central-1 | ami-022ac40db882265aa |
| ap-southeast-1 | ami-09ab2b10aa42da416 |
| ap-southeast-2 | ami-02355156987d8fbaa |
| eu-central-1 | ami-02ef7c0fff22b1954 |
| us-east-1 | ami-0a9b5046374af8659 |
| us-east-2 | ami-0a2c50588ce10ffc6 |
| us-west-1 | ami-059ac57b261e8332d |
| us-west-2 | ami-00d2c656a4b5beaaf |
