# How to Publish AMIs in a New Account

See the [canonical page](https://github.com/hashicorp/terraform-aws-consul/blob/master/_ci/publish-amis-in-new-account.md)
in the [Consul AWS Module](https://github.com/hashicorp/terraform-aws-consul) repo.