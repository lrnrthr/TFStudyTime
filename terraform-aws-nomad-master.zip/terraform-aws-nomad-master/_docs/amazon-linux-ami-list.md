# amazon-linux-ami: Latest Public AMIs

**WARNING! Do NOT use these AMIs in a production setting.** The AMIs are meant only to make initial experiments with this module more convenient.

| AWS Region | AMI ID |
| ---------- | ------ |
| ap-south-1 | ami-026aae098da56e7ce |
| eu-west-3 | ami-05fcd752d7163b6c8 |
| eu-west-2 | ami-00a938184575427ca |
| eu-west-1 | ami-0d9516a85e0c28bb0 |
| ap-northeast-2 | ami-05398a2a35479b69f |
| ap-northeast-1 | ami-0f989098e01473edf |
| sa-east-1 | ami-0bfc339cb5eaaf46f |
| ca-central-1 | ami-06db3609415c687df |
| ap-southeast-1 | ami-0ba12c7eb87200b1f |
| ap-southeast-2 | ami-0e19b4557bf3d0aad |
| eu-central-1 | ami-0ed6a4bca29eaf964 |
| us-east-1 | ami-0ea8448312bb874e8 |
| us-east-2 | ami-07558fd46c4cfffe5 |
| us-west-1 | ami-05d50b72b8ba0c421 |
| us-west-2 | ami-02428a5b65fbfebe7 |
