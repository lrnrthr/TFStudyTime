# ubuntu16-ami: Latest Public AMIs

**WARNING! Do NOT use these AMIs in a production setting.** The AMIs are meant only to make initial experiments with this module more convenient.

| AWS Region | AMI ID |
| ---------- | ------ |
| ap-south-1 | ami-02fe5397408a3359d |
| eu-west-3 | ami-06525423a90c69e63 |
| eu-west-2 | ami-0f5b77f5e53001306 |
| eu-west-1 | ami-0ef8f63a8b2b240b9 |
| ap-northeast-2 | ami-08fee57e9c1f02a38 |
| ap-northeast-1 | ami-09f8af691b77b4bcc |
| sa-east-1 | ami-0d0508a6fe4f2a475 |
| ca-central-1 | ami-08ac5687f26df69d7 |
| ap-southeast-1 | ami-01fa8cb8e72a07cdc |
| ap-southeast-2 | ami-0a017bf6111567148 |
| eu-central-1 | ami-0242cf8a8a18dd6a9 |
| us-east-1 | ami-03679e1c6e7585efb |
| us-east-2 | ami-030f4d3c47461eb59 |
| us-west-1 | ami-0f55feb1cd4842199 |
| us-west-2 | ami-0901a4027c8ceff0d |
